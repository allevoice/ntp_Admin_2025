<?php

namespace App\Controller\Admin;

use App\Model\Post;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Contracts\Translation\TranslatorInterface;


#[Route('/admin/post', name: 'app_admin_post_')]
class PostController extends AbstractController
{
    #[Route('/', name: 'liste')]
    public function index(TranslatorInterface $translator,Request $request,Post $post): Response
    {
        $searchTerm = $request->query->get('search', '');
        $currentPage = $request->query->getInt('page', 1);

        $limite = '5';
        // 1. Appel du Service
        $data = $post->getPaginatedItems($currentPage, $limite, $searchTerm);
        $totalItems = $data['total'];

        // 2. Calcul des variables de pagination
        $totalPages = (int) ceil($totalItems /$limite);

        // Assurer que la page actuelle est valide
        $currentPage = max(1, min($currentPage, $totalPages > 0 ? $totalPages : 1));

        // Pour le comptage des donnee dans la table en affichant le nombre par page
        $start_index = ($currentPage - 1) * $limite;



        //dd($data,$data['items']);
     

        return $this->render('admin/post/index.html.twig', [
            'nav_link' => 'post-liste-nav',
            'titlepage' => $translator->trans('title_page_post_liste'),


            'items' => $data['items'],      // Les éléments de la page
            'searchTerm' => $searchTerm,    // Le terme de recherche
            'currentPage' => $currentPage,  // Page actuelle
            'comptage' => $start_index,    // Total des pages
            'totalPages' => $totalPages,    // Total des pages

        ]);
    }















}
