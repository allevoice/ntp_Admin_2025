<?php


namespace App\Model;


use Symfony\Component\HttpFoundation\Session\Session;

class Mainmodel
{

    protected $table;
    protected $id;
    protected $pdo;
    protected $sql_queries;
    protected $search_term;



    protected function tableExists($table) {
        try {
            $result = $this->pdoconnect()->query("SELECT 1 FROM $table LIMIT 1");
        } catch (\Exception $e) {
            return FALSE;
        }
        return $result !== FALSE;
    }



    public function getLocaleFromSession()
    {
        $session = new Session();
        // Utilisez ->get() pour récupérer la valeur associée à la clé '_locale'
        $locale = $session->get('_locale');
        return $locale;
    }


    public function pdoconnect(){

        $host = $_ENV['MYSQL_HOST'] ?? 'localhost';
        $dbname = $_ENV['MYSQL_DBNAME'] ?? 'ntpsams_2025';
        $user = $_ENV['MYSQL_USER'] ?? 'root';
        $pwd = $_ENV['MYSQL_PWD'] ?? '';
        $utf= $_ENV['MYSQL_UTF'] ?? 'utf8';

        //dd($host,$dbname,$utf, $user,$pwd);


        if(!isset($this->pdo)){
            $this->pdo = new \PDO('mysql:host='.$host.';dbname='.$dbname.';charset='.$utf, $user,$pwd);            
            return $this->pdo;
        }else{
            return $this->pdo;
        }

    }



    public function getPaginatedItems_BAK(int $page, int $limit, string $searchTerm = NUll): array
    {

        $offset = ($page - 1) * $limit;
        $params = [];
        $whereClause = '';


        // 1. Définition de la clause WHERE pour la recherche (sans injection grâce à bindValue)
        if (!empty($searchTerm)) {
            $whereClause = " WHERE (title LIKE :search OR content LIKE :search OR created_at LIKE :search) ";
            $params[':search'] = '%' . $searchTerm . '%';
        }

        // --- 2. Requête pour le nombre total de résultats (avec filtre) ---
        $countSql = "SELECT COUNT(id) FROM {$this->table}" . $whereClause;
        $stmtCount = $this->pdoconnect()->prepare($countSql);

        // Bind le paramètre de recherche pour le COUNT
        if (!empty($searchTerm)) {
            $stmtCount->bindValue(':search', $params[':search']);
        }
        $stmtCount->execute();
        $totalResults = $stmtCount->fetchColumn();


        // --- 3. Requête pour les données de la page courante ---
        $dataSql = "SELECT * FROM {$this->table}"
            . $whereClause
            . " ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}";

        $stmtData = $this->pdoconnect()->prepare($dataSql);

        // Bind le paramètre de recherche (si présent)
        if (!empty($searchTerm)) {
            $stmtData->bindValue(':search', $params[':search']);
        }

        $stmtData->execute();
        $items = $stmtData->fetchAll();

       
    

        // Retourne les deux ensembles de données pour le contrôleur/Twig
        return [
            'items' => $items,
            'total' => $totalResults,
        ];
    }



public function getPaginatedItems(int $page, int $limit, string $searchTerm = NULL): array
{
    $offset = ($page - 1) * $limit;
    $pdo = $this->pdoconnect(); // Assurez-vous que ceci retourne l'objet PDO
    $whereClause = '';
    $params = [];
    
    // 1. Définition de la clause WHERE pour la recherche (avec correction DATE())
    if (!empty($searchTerm)) {
        // Utiliser DATE() rend la recherche par date plus précise/fonctionnelle pour les chaînes.
        $whereClause = " WHERE (title LIKE :search OR content LIKE :search OR DATE(created_at) LIKE :search) ";
        $params[':search'] = '%' . $searchTerm . '%';
    }

    // --- 2. Requête pour le nombre total de résultats (avec filtre) ---
    $countSql = "SELECT COUNT(id) FROM {$this->table}" . $whereClause;
    $stmtCount = $pdo->prepare($countSql);

    // Bind le paramètre de recherche pour le COUNT
    if (!empty($searchTerm)) {
        $stmtCount->bindValue(':search', $params[':search']);
    }
    $stmtCount->execute();
    $totalResults = $stmtCount->fetchColumn();


    // --- 3. Requête pour les données de la page courante (avec binding) ---
    $dataSql = "SELECT * FROM {$this->table}"
        . $whereClause
        . " ORDER BY created_at DESC LIMIT :limit OFFSET :offset"; // <-- Variables de binding restaurées

    $stmtData = $pdo->prepare($dataSql);

    // Bind le paramètre de recherche (si présent)
    if (!empty($searchTerm)) {
        $stmtData->bindValue(':search', $params[':search']);
    }

    // CORRECTION CRUCIALE : Indiquer explicitement que ce sont des ENTIERS (selon la version qui marchait)
    $stmtData->bindValue(':limit', $limit, \PDO::PARAM_INT);
    $stmtData->bindValue(':offset', $offset, \PDO::PARAM_INT); 

    $stmtData->execute();
    // ATTENTION : Utiliser FETCH_ASSOC pour un tableau associatif manipulable pour le surlignage
    $items = $stmtData->fetchAll(\PDO::FETCH_ASSOC); 

    // ----------------------------------------------------
    // 4. LOGIQUE DE SURLIGNAGE (Injection HTML)
    // ----------------------------------------------------
    if (!empty($searchTerm) && !empty($items)) {
        
        $highlightTag = '<span class=\'terme-recherche\'>'; 
        $closeTag = '</span>';
        
        // Terme à surligner (sans les %)
        $termToHighlight = str_replace('%', '', $params[':search']); 
        
        // Surligner le terme dans le titre et le contenu
        foreach ($items as &$item) {
            
            // Surligner le TITRE (insensible à la casse)
            $item['title'] = str_ireplace(
                $termToHighlight, 
                $highlightTag . $termToHighlight . $closeTag,
                $item['title']
            );
            
            // Surligner le CONTENU (insensible à la casse)
            $item['content'] = str_ireplace(
                $termToHighlight, 
                $highlightTag . $termToHighlight . $closeTag,
                $item['content']
            );
            // La date est surlignée dans Twig
        }
        unset($item); 
    }
    // ----------------------------------------------------

    // Retourne les deux ensembles de données pour le contrôleur/Twig
    return [
        'items' => $items,
        'total' => $totalResults,
    ];
}







    
    public function insert(){
        $set_placeholders = [];
        foreach ($this->sql_queries as $column => $value) {
            // Résultat pour chaque paire : "nom = :nom"
            $set_placeholders[] = "$column = :$column";
        }
        $sql = "INSERT INTO $this->table SET " . implode(', ', $set_placeholders);
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute($data);


    }


    public function delsoft(){
        $stmt=$this->pdoconnect()->prepare("UPDATE ".$this->table." SET status_data=:statuts, deleted_at=:deleted_at WHERE id=:id_get ");
        $stmt->bindValue(':id_get',$this->getId());
        $stmt->bindValue(':statuts',NULL);
        $stmt->bindValue(':deleted_at',$this->today());
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function delrestaure()
    {
        $stmt=$this->pdoconnect()->prepare("UPDATE ".$this->table." SET deleted_at=:deleted_at WHERE id=:id_get ");
        $stmt->bindValue(':id_get',$this->getId());
        $stmt->bindValue(':deleted_at',NULL);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function deldefitly()
    {
        $stmt=$this->pdoconnect()->prepare("DELETE FROM ".$this->table." WHERE id=:id_get ");
        $stmt->bindValue(':id_get',$this->getId());
        $stmt->execute();
        return $stmt->rowCount();
    }



    public function readfirstdata(){
        $stmt= $this->pdoconnect()->prepare("SELECT * FROM ".$this->table);
        $stmt->execute();
        return $stmt->fetch();
    }




    public function hashcmd($data, $action){
        //return (hash('sha224', $data));

        //$action = 'd';
        //$data = 'codeview';
        //$data = 'Z25jMzBwNFFSSjZmdm44VWM1dXYwdz09';
        //$secret_key = 'my_simple_secret_key';
        $secret_key = 'not_key_ntpsams_success';
        //$secret_iv = 'my_simple_secret_iv';
        $secret_iv = 'not_key_secret_ntpsams';


        $output = false;
        $encrypt_method = "AES-256-CBC";
        $key = hash( 'sha256', $secret_key );
        $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

        if( $action == 'c' ) {
            $output = base64_encode( openssl_encrypt( $data, $encrypt_method, $key, 0, $iv ) );
        }
        else if( $action == 'd' ){
            $output = openssl_decrypt( base64_decode( $data ), $encrypt_method, $key, 0, $iv );
        }

        return $output;

    }




    public function passwordcrypter($data){

        $output = hash_pbkdf2("sha256", $data, md5($data), '1000', 90);
        //$output = crypt($data, '$6$rounds=5000$usesomesillystringforsalt$');
        return $output;

    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getPdo()
    {
        return $this->pdo;
    }

    /**
     * @param mixed $pdo
     */
    public function setPdo($pdo)
    {
        $this->pdo = $pdo;
    }



    /**
     * @return mixed
     */
    public function getSearchTerm()
    {
        return $this->search_term;
    }

    /**
     * @param mixed $search_term
     */
    public function setSearchTerm($search_term)
    {
        $this->search_term = $search_term;
    }






}
