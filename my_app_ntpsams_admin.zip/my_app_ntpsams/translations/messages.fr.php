<?php
return[


    //===============================================================
    //==================== Title Page Public=========================
    //===============================================================
    'title_pub_page_home' => 'Accueil',
    'title_pub_page_service' => 'Services',

    //===============================================================



    //===============================================================
    //================ Botton website Public=========================
    //===============================================================
    'learn_more' => 'Lire la suite',

    //===============================================================




    //===============================================================
    //==================== LOGIN COMMANDE ===========================
    //===============================================================
    'log_in'=>'Connectez-vous',
    'label_address_email'=>'Adresse Email',
    'email_address_placeholder'=>'Inserez votre addresse Electronique',
    'label_pwd_title'=>'Mot de Passe',
    'pwd_title_placeholder'=>'Inserez votre Mot de Passe',
    'link_title_forget_pwd'=>'Mot de passe oublié ?',
    'btn_title_login'=>'Connexion',
    'title_texte_account'=>'Vous n\'avez pas de compte ?',
    'link_title_account'=>'Créer un compte maintenant',
    //===============================================================
    //==================== LOGIN COMMANDE ===========================
    //===============================================================


];
